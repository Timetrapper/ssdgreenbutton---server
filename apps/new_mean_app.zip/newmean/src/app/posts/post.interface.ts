export interface IPost {
    postId: number;
    title: string;
}