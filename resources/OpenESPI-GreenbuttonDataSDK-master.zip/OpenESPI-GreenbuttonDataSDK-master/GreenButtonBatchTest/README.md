Green Button Data Batch Test
===========================

This folder contains tools to batch test Green Button data files. It supports upwards of several gigabyte data files containing many Usage Points.
