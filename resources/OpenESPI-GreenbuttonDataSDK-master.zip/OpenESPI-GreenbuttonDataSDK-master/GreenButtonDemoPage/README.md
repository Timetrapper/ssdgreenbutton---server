Green Button Demo Page
===========================

This folder contains a sample web page that allows you to view Green Button data and plot it using the highcharts plotting package. 

Note: highcharts is a commercial product which must be licensed for commercial use.
