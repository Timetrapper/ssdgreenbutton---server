This folder contains a prototype demonstration of how to transform a Green Button data file without cost to one with cost.

Note: some files such as schemas are drafts and not current at this time. 
