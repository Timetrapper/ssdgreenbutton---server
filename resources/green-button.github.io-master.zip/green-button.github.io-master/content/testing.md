Content from: http://www.greenbuttondata.org/greentest.aspx
-
Testing

TEST YOUR GREEN BUTTON DATA FILE

Use this test to evaluate and analyze the inner structure of a Green Button data file.

1) Select the scope of your Green Button data file:


2) You can override and make additional selections of Function Blocks to test:

 [FB_1] Common
 [FB_4] Interval Metering
 [FB_5] Interval Electricity Metering
 [FB_6] Demand Electricity Metering
 [FB_7] Net Metering
 [FB_8] Forward and Reverse Metering
 [FB_9] Register Values
 [FB_10] Gas
 [FB_11] Water
 [FB_12] Cost of Interval Data
 [FB_15] Usage Summary
 [FB_16] Usage Summary with Cost
 [FB_17] Power Quality Summary
 [FB_27] Usage Summary with Demands and Previous Day Attributes
 [FB_28] Usage Summary Costs for Current Billing Period
 [FB_29] Temperature Metering

3) Please consider checking this box to allow us to keep your file on our server for further tests. Otherwise the file will be deleted after analysis:

 Allow file to be saved on website

4) Enable download of test results after test execution:

 Download test results


5) Drop file here to upload.

Note: This web page was tested with the following browsers:
PC: Internet Explorer V9.0.8112.16421, Fire Fox V19.0.2, Safari V5.1.7, Chrome V25.0.1364.152
Mac: Fire Fox V19.0.2, Safari V6.0.2, Chrome V25.0.1364.160

TEST RESULTS
