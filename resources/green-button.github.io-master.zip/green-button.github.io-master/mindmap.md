---
layout: page
title: Green Button Mindmap
---

<section class="mindmap">
<h2><a href="../Green%20Button%20for%20America.mm">Toplevel Green Button Mindmap</a><a href="http://freeplane.sourceforge.net/wiki/index.php/Main_Page">(requires freeplane)</a></h2>
<img  class="img-responsive" src = "images/MindMap2.png" />
<h3>Full View</h3>
<img  class="img-responsive" src = "images/MindMap1.png" />
<h3><a href="../NationalPilots.mm">National Pilots(private)</a><a href="http://freeplane.sourceforge.net/wiki/index.php/Main_Page">(requires freeplane)</a></h3>
<img  class="img-responsive" src = "images/NationalPilots.png" />
<h3>Los Angeles(private)</h3>
<img  class="img-responsive" src = "images/MindMap_LosAngeles.png" />
<h3><a href="Federal%20Green%20Button%20Effort.mm">Federal Green Button Efforts(private)</a></h3>
<img  class="img-responsive" src = "images/Mind.png" />
</section>
