export default {
  ACTUAL: 'interval-type-actual',
  THEORETICAL: 'interval-type-theoretical'
}
