export default {
  AVG_DAY: 'avg-day',
  AVG_WEEKEND_DAY: 'avg-weekend-day',
  AVG_WEEK_DAY: 'avg-week-day',
  AVG_PEAK_TIME: 'avg-peak-time',
  ALL_TIME: 'all-time',
  LAST_30_DAYS: 'last-30-days',
  LAST_7_DAYS: 'last-7-days',
  MOST_RECENT_24_HOURS: 'most-recent-24-hours'
}
