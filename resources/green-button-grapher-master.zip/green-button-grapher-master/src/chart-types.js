export default {
  COST: 'chart-type-cost',
  POWER_USAGE: 'chart-type-power-usage'
}
