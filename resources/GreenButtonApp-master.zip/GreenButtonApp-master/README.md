[![Build Status](https://travis-ci.org/vincechan/GreenButtonApp.svg?branch=master)](https://travis-ci.org/vincechan/GreenButtonApp)

# GreenButtonApp

This is a [Green Button Data](http://www.greenbuttondata.org/) visualizer built with Angular. [Demo](https://vincechan.github.io/GreenButtonApp/)

